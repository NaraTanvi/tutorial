# FARM PROJECT DJANGO
## contains models and views for farm,farmers and their schedule details related to their farm.
### dependencies:
    -> install mysql
    -> create database farmdbdjango in mysql db
    -> activate environment and install Django version 1.10.5
    -> run server by python manage.py runserver.
