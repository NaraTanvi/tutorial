from django.apps import AppConfig


class FarmappConfig(AppConfig):
    name = 'farmapp'
